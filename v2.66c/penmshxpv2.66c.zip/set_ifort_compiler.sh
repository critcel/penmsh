##set ifort to the correct path
module load intel_compilers/12.0.3.174 intel_mpi/4.0.1.007

